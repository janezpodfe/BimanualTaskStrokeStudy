﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class start : MonoBehaviour {

    public myUDP other;
    public Vector2 startPos;
    private float triger,x,xx;
    public float k ;
    public float trgIn;
    public float l=0 ;
    private float lock1 = 0;
   

	// Use this for initialization
	void Start () {
        other = GameObject.FindObjectOfType<myUDP>();
        k = 0;
        other.setIntialTriger(1, 1);
      
	}
	
	// Update is called once per frame
	void Update () {
        trgIn = other.trg_in();
        //other.setAimPosition(7, 7, 7);
        startPos = other.getStartPos();
        transform.position = startPos;
        triger = other.visiable();
        x = other.startTrg();
        if (trgIn == 1)
        {
            l = 1;
        }

        if (triger == 1)
        {


            //Invoke("dissapp", 3.0f);
            dissapp();

        }
        if (x == 1)
        {
            xx = 500;
        }
     
      
        other.setTargetPosition(k,k,xx);
        other.setIntialTriger(l,l);
	}
    void dissapp(){
       // GameObject.Find("start").transform.localScale = new Vector3(0, 0, 0);
        k = 500.7f;
    }
   
}
