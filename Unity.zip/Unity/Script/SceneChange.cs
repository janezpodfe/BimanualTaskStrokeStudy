﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SceneChange : MonoBehaviour {

    public Server other_1;

    public string Game;
	//public float height;
	//public float weight;
    public InputField Height;
    public InputField Weight;
    public float x = 1.1f;

    // Use this for initialization
    void Start()
    {
        other_1 = GameObject.FindObjectOfType<Server>();
    }

    // Update is called once per frame
    void Update()
    {
     //   Debug.Log("height =" + Height);
     //   Debug.Log("height =" + Weight);
    }

    public  void PassGame(string sceneName) {
      //  height = float.Parse(Height.text);
      //  weight = float.Parse(Weight.text);
        

        SceneManager.LoadScene(sceneName);

	}
    // string sceneName
    public void SaveVar (string newText)
    {
        float  height = float.Parse(newText);
        Debug.Log("Height=" + height);
        //float  weight = float.Parse(Weight);
        //   other_1.setPatientAnthropometry(height, weight);
    }

	
	public  void GameOut() {
		Application.Quit ();
	}
	
	
	
	
	
}
