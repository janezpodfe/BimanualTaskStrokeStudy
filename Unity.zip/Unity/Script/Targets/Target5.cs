﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target5 : MonoBehaviour
{

    //	public float spawnTime = 3f;

    public float rotateSpeedX;
    public float rotateSpeedY;
    //	public float centerPointPositionOffsetX;
    public float rotateSpeedZ = 25.0f;



    public float trgSecond = 0;
    public float triger = 0;
    private float trg_target2 = 0;
    private float trg_target3 = 0;
    private float trg_target4 = 0;
    private float trg_target5 = 0;
    public float l1 = 0;
    private float l2 = 0;
    private float l3 = 0;
    private float l4 = 0;
    private float lock_end = 0;

    private float j;
    private float j1;
    private float k;

    public Vector2 targetPos;


    public Vector3 StartPosition_Plane = new Vector3(5.0f, 3.0f, 0);
    public myUDP other;
    public Vector3 desired_point = new Vector3(5.0f, 3.0f, 0);


    // Use this for initialization
    void Start()
    {
        //GameObject.Find("Target5").transform.localScale = new Vector3(0, 0, 0);
        // counter = 0;
        other = GameObject.FindObjectOfType<myUDP>();
        j = 20;
        k = 20;

         Spawn();
        //	transform.position = StartPosition_Plane;
        GameObject.Find("Target5").transform.localScale = new Vector3(1.5f, 1.5f, 1);



    }

    // Update is called once per frame
    void Update()
    {
        triger = other.visiable();
        trgSecond = other.trg_in();
        trg_target2 = other.trg_target2();
        trg_target3 = other.trg_target3();
        trg_target4 = other.trg_target4();
        trg_target5 = other.trg_target5();
        if (triger == 1 || l1 == 1)
        {
            l1 = 1;
        }
        if (trgSecond == 1 || l2 == 1)
        {
            l2 = 1;

        }
        if (trg_target2 == 1 || l2 == 1)
        {
            l2 = 1;
        }
        if (trg_target3 == 1 || l3 ==1)
        {
            l3 = 1;
        }

        if (trg_target4 == 1 && l3 == 1)
        {
            //Invoke("app", 3.0f);
            j = 1.5f;
            j1 = 5.4f;
           // Invoke("Spawn", 3);
        }
        if (trg_target5 == 1)
        {
            j = 50;
            j1 = 50;
           // Invoke("app", 3);
            lock_end = 55;
        }

        other.endLock(lock_end);
        targetPos = other.getTargetPos();
        Spawn();

    }

    public void Spawn()
    {

        Vector3 targetPos_1 = new Vector3(targetPos.x - j, targetPos.y + j1, 0);
        transform.position = targetPos_1;





    }
    void app()
    {
        j = 50;
        Spawn();
        //GameObject.Find("Rec").transform.localScale = new Vector3(1, 1, 1);
    }




}