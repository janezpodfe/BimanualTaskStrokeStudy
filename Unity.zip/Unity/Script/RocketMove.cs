﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Aim : MonoBehaviour {
	
	public float speed = 1.0f;	
	public float rotateSpeedX = 0;
	public float rotateSpeedY = 0;
	public float rotateSpeedZ = 25;
	
	
	public Vector3 possition;
	
	public int counter_1;
	public int comp_counter;
	public Vector3 plane_position;
	public Quaternion plane_rotation;
	public Quaternion rocket_rotation;
	
	public Animator anim;
	
	public float angle_rad;
	public float angle;
	public float controlSignal1;
	
	
	public float roc_angle_rad;
	public float roc_angle;
	
//	public Server other;
//	 udpServer;
	private float try1;
	private float try2;
	public float try3 =3.0f;
	public float try4 =4.1f;
	
	
	public myUDP other;

    public Vector3 movement;
	
	


	// Use this for initialization
	void Start () {
		
	//	counterAngle = 0;
	anim = GetComponent<Animator>();

other = GameObject.FindObjectOfType<myUDP>();



    }
	
	// Update is called once per frame
	void Update () {
//		_ServerToMove.setScaling(float scaleFactorX = 1.0f,scaleFactorY);
		
		var move = new Vector3(Input.GetAxis("Horizontal"),Input.GetAxis("Vertical"),0);
		transform.position += move * speed * Time.deltaTime;
		
		
		if(Input.GetKey(KeyCode.O))
		{
			
			transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY* Time.deltaTime, rotateSpeedZ * Time.deltaTime);
		
			if(comp_counter < 360){
				comp_counter++;
//				Debug.Log("counter rocket" + comp_counter);
			}
			
		}
		if(Input.GetKey(KeyCode.L))
		{
			
			transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY* Time.deltaTime, -rotateSpeedZ * Time.deltaTime);
			comp_counter--;
//			Debug.Log("counter rocket" + comp_counter);
		}
		
		possition = transform.position;
//	Debug.Log("current pos is" + possition);
		counter_1 = GameObject.Find("Fly (2)").GetComponent<PlaneMove>().counter;
//	Debug.Log("counter is" + counter_1);
	
	// getting a initial position of plane
	
//	plane_position = GameObject.Find("Fly (2)").GetComponent<PlaneMove>().SpawnPosition;

	plane_position = GameObject.Find("Fly (2)").transform.position;
	
	plane_rotation = GameObject.Find("Fly (2)").transform.rotation;
//		Debug.Log("plane pos" + plane_rotation);
		
		angle_rad = (Mathf.Asin(plane_rotation.z/plane_rotation.w));
		angle = angle_rad* Mathf.Rad2Deg;
//		Debug.Log("angle" + angle);
		
	rocket_rotation = GameObject.Find("BlenderRocket").transform.rotation;
	
        roc_angle_rad =(Mathf.Asin(rocket_rotation.z/rocket_rotation.w));
        roc_angle = roc_angle_rad * Mathf.Rad2Deg;
//        Debug.Log("rocket angle" + roc_angle);
//        controlSignal1 = angle;
	

	
	
/*	if ( possition.x >plane_position.x-0.5 && possition.y >plane_position.y-0.5 && possition.x<plane_position.x+0.5 && 
	    possition.y<plane_position.y+0.5  && roc_angle < angle+5 && roc_angle > angle-5 )
	{
//		transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY* Time.deltaTime, rotateSpeedZ * Time.deltaTime);
     	anim.Play("BlowUp");
	}
	else 
	{
		anim.Play("OrdRocket");
	} */
//	udpServer.setScaling( scaleFactorX, scaleFactorY);

	
        movement = other.getHandPosition();
        transform.position = movement;
        other.setAimPosition(movement.x,movement.y,move.z);

    }
}
