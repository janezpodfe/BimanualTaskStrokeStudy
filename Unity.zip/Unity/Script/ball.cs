﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ball : MonoBehaviour {

    public myUDP other;
    public Vector2 getUnit;
    private float unit_vector;
    private float vel;
    private float times = 0;
    public static float time;
    public Vector2 startPos;
    private Vector3 movementofBall;
    private Vector2 temp;
    private float triger;
    private float x;
  
    //public Vector2 startPos;
   
	// Use this for initialization
	void Start () {
        other = GameObject.FindObjectOfType<myUDP>();
       // startPos = other.getStartPos();
        transform.position =new Vector3 (-5.2f,-0.5f,0);
        GameObject.Find("ball").transform.localScale = new Vector3(0, 0, 0);
        x = 0;


        
	}
	
	// Update is called once per frame
	void Update () {
        
       // unit_vector = getVel.x;
       // vel = getVel.y;
        startPos = other.startBall();
        getUnit = other.getUnitVector();
        vel = other.vel();
     //   transform.position = startPos;
             

        triger = other.visiable();
       

        //times = Time.realtimeSinceStartup;
       
        
        Debug.Log("time" + Time.deltaTime);
        

       // transform.position = movementofBall;

        if (triger == 1 || x == 1 )
        {
            
            GameObject.Find("ball").transform.localScale = new Vector3(1, 1, 1);
            x = 1;
            Invoke("constantMove", 3.0f);
     
            
        }
        
	}

    void constantMove()
    {
        times = times + Time.deltaTime;
        movementofBall = startPos + (getUnit * vel * (times));
        transform.position = movementofBall;
        if (movementofBall.x > 5.5f && movementofBall.y < -4)
        {
            //GameObject.Find("ball").transform.localScale = new Vector3(0, 0, 0);
            transform.position = new Vector3(5.5f, -4f, 0);
        }
    }
}
