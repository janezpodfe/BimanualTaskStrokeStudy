﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneMove : MonoBehaviour {
	
//	public GameObject Fly;
//	public float spawnTime = 3f;
	
	public float rotateSpeedX;
	public float rotateSpeedY;
//	public float centerPointPositionOffsetX;
	 public float rotateSpeedZ = 25.0f;
	
	public int counter= -150;
    private int counter_2 = 0;
    private int x = 75;
    private int y = 75;
    private int z = 225;
    public float triger = 0;
    private float trgSecond = 0;

    private float j;
    private float k;
    private float delay;

    public Vector2 targetPos;

	
	public Vector3 StartPosition_Plane = new Vector3(5.0f,3.0f,0);
	public myUDP other;
	public Vector3 desired_point =new Vector3 (5.0f,3.0f,0);
    

	// Use this for initialization
	void Start () {
       // GameObject.Find("Rec").transform.localScale = new Vector3(0, 0, 0);
        //transform.position = new Vector3 (10,10
       // counter = 0;
		other = GameObject.FindObjectOfType<myUDP>();
        j = 20;
        k = 20;
       
        Spawn();
//	transform.position = StartPosition_Plane;

		
			
	}
	
	// Update is called once per frame
	void Update () {
        triger = other.visiable();
        trgSecond = other.trg_in();
        if (triger == 1)
        {
           // Invoke("app", 3.0f);
            j = 0;
            delay = 3.0f;
            //Invoke("Spawn", 3);
            Spawn();
        }

        else
        {
           // delay = 0;
        }
        if (trgSecond == 1)
        {
            delay = 3.0f;
            j = 20;
           // Invoke("Spawn", 3);
         
           // Spawn();
            app();
    
        
        }
		//desired_point = other.getHandPosition();
		//Debug.Log("desired x" + desired_point.x);

        //dondurmeyi alt satirdan durdurdum
		//RotationPlane();
        
        //other.setTargetPosition(desired_point.x, desired_point.y, desired_point.z);
         float  xx = 3.1f;
       // other.setTargetPosition(xx,xx,xx);
      //  targetPos = other_1.getTargetPos();
        targetPos = other.getTargetPos();
        //Spawn();
       // Invoke("app", delay);
       

    }
	
	public void Spawn (){
        
        Vector3 targetPos_1 = new Vector3(targetPos.x+j, targetPos.y+j, 0);
        transform.position = targetPos_1;

        //ust taraftakiler matlabden veri alirken
        
		//float spawnPointX = Random.Range(-7.5f,7.5f);
		//int spawnPointY = Random.Range(-4,4);
		
		//Vector3 spawnPosition = new Vector3(spawnPointX,spawnPointY,0);
		//transform.position =spawnPosition;  
        // ust 4 satir kod unityden veri alirken

        //desired_point = spawnPosition;



        //		transform.position =desired_point;

        //		centerPointPositionOffsetX = spawnPointX;
        //other.setTargetPosition(spawnPosition.x, spawnPosition.y, spawnPosition.z);



    }
    void app()
    {
       // targetPos = other.getTargetPos();
      //  GameObject.Find("Rec").transform.localScale = new Vector3(1, 1, 1);
        GameObject.Find("Rec").transform.localScale = new Vector3(0, 0, 0);
    }



    void RotationPlane()
    {
        transform.eulerAngles = new Vector3(0, 0, counter);
        if (counter_2 < x)
        {
            counter++;
            counter_2++;
        }
        if (counter_2 >= y)
        {
            counter--;
            counter_2++;
        }
        if (counter_2 == z)
        {
            counter_2 = 0;
            x = 150;
            y = 150;
            z = 300;
        }
    }
	/*void RotationPlane() {
		counter++;
		
		if (counter < 180 ) {
			
			
			transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY* Time.deltaTime, rotateSpeedZ* Time.deltaTime ,Space.World);
		
		}
		else {
			
			transform.Rotate(-rotateSpeedX * Time.deltaTime, -rotateSpeedY* Time.deltaTime, -rotateSpeedZ* Time.deltaTime,Space.World);
			
		}
		
		if (counter > 360) {
			
			counter = 0;
		}
	} */

}
