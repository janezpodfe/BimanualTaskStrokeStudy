﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target3 : MonoBehaviour
{

    //	public float spawnTime = 3f;

    public float rotateSpeedX;
    public float rotateSpeedY;
    //	public float centerPointPositionOffsetX;
    public float rotateSpeedZ = 25.0f;



    public float trgSecond = 0;
    public float triger = 0;
    private float trg_target2 = 0;
    private float trg_target3 = 0;
    public float l1 = 0;
    private float l2 = 0;

    private float j;
    private float j1 =0;
    private float k;

    public Vector2 targetPos;


    public Vector3 StartPosition_Plane = new Vector3(5.0f, 3.0f, 0);
    public myUDP other;
    public Vector3 desired_point = new Vector3(5.5f, 3.5f, 0);


    // Use this for initialization
    void Start()
    {
        //GameObject.Find("Target3").transform.localScale = new Vector3(0, 0, 0);
        // counter = 0;
        other = GameObject.FindObjectOfType<myUDP>();
        j = 20;
        k = 20;
       
         Spawn();
        //	transform.position = StartPosition_Plane;



    }

    // Update is called once per frame
    void Update()
    {
        triger = other.visiable();
        trgSecond = other.trg_in();
        trg_target2 = other.trg_target2();
        trg_target3 = other.trg_target3();
        if (triger == 1 || l1 == 1)
        {
            l1 = 1;
        }
        if (trgSecond == 1 || l2 == 1)
        {
            l2 = 1;
            
        }
        if (trg_target2 == 1 && l2 == 1)
        {
            //Invoke("app", 3.0f);
            j = 8.2f;
            j1 = 6.4f;
            //Invoke("Spawn", 3);
        }
        if (trg_target3 == 1)
        {
            j = 15;
          //  Invoke("app", 3);
     
        }
        //desired_point = other.getHandPosition();
        //Debug.Log("desired x" + desired_point.x);

        //dondurmeyi alt satirdan durdurdum
        //RotationPlane();

        //other.setTargetPosition(desired_point.x, desired_point.y, desired_point.z);
        float xx = 3.1f;
        // other.setTargetPosition(xx,xx,xx);
        //  targetPos = other_1.getTargetPos();
        targetPos = other.getTargetPos();
        Spawn();

    }

    public void Spawn()
    {

        Vector3 targetPos_1 = new Vector3(targetPos.x - j, targetPos.y + j1, 0);
        transform.position = targetPos_1;

        //ust taraftakiler matlabden veri alirken

        //float spawnPointX = Random.Range(-7.5f,7.5f);
        //int spawnPointY = Random.Range(-4,4);

        //Vector3 spawnPosition = new Vector3(spawnPointX,spawnPointY,0);
        //transform.position =spawnPosition;  
        // ust 4 satir kod unityden veri alirken

        //desired_point = spawnPosition;



        //		transform.position =desired_point;

        //		centerPointPositionOffsetX = spawnPointX;
        //other.setTargetPosition(spawnPosition.x, spawnPosition.y, spawnPosition.z);



    }
    void app()
    {
        j = 15;
        Spawn();
        //GameObject.Find("Rec").transform.localScale = new Vector3(1, 1, 1);
    }




}