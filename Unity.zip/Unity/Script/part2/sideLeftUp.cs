﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sideLeftUp : MonoBehaviour {

    // Use this for initialization
    public myUDP other;
    SpriteRenderer m_spriteRenderer;
    Color m_newColor;

    private Vector3 movement;
    private float rotateFactor;

    void Start()
    {
        other = GameObject.FindObjectOfType<myUDP>();
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        m_spriteRenderer.color = Color.black;

    }

    // Update is called once per frame
    void Update()
    {
       

        rotateFactor = other.smallMotor();
        transform.localEulerAngles = new Vector3(0, 0, -rotateFactor*100/2);

        if (rotateFactor < 0)
        {
            rotateFactor = -1 * rotateFactor;
        }
        transform.localScale = new Vector3(1, 1 + ((rotateFactor * 4.0f) / 10), 1);

  
    }
}