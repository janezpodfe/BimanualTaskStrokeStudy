﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class siderightdow : MonoBehaviour {
    // Use this for initialization
    public myUDP other;
    SpriteRenderer m_spriteRenderer;
    Color m_newColor;

    private Vector3 movement;
    private float rotation;
   

    void Start()
    {
        other = GameObject.FindObjectOfType<myUDP>();
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        m_spriteRenderer.color = Color.black;
   

    }

    // Update is called once per frame
    void Update()
    {


        rotation = other.smallMotor();
     
        transform.localEulerAngles = new Vector3(0, 0,-rotation * 100/2);
        if (rotation < 0)
        {
            rotation = -1 * rotation;
        }
        transform.localScale = new Vector3(1, 1 + ((rotation * 4) / 10), 1);

   
    }
}
