﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class general : MonoBehaviour
{
    // Use this for initialization
    public myUDP other;
    SpriteRenderer m_spriteRenderer;
    Color m_newColor;

    private Vector3 movement;
    private float rotateFactor;
    private float growFactor;
    private float counter;

    private float grow_limit = 0.95f;
    private float grow_up = 1.05f;
    private float triger;
    public float trgIn;

    private float trg_target2 = 0;
    private float trg_target3 = 0;
    private float trg_target4 = 0;
    private float trg_target5 = 0;

    private float l = 0;
    private float l2 = 0;


 

    void Start()
    {
        other = GameObject.FindObjectOfType<myUDP>();
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        m_spriteRenderer.color = Color.black;
        counter = 0;

     
        foreach (SpriteRenderer general in GetComponentsInChildren<SpriteRenderer>())
        {
             general.material.color = Color.red;
         }
    }

    // Update is called once per frame
    void Update()
    {
        movement = other.getHandPosition();
       // movement = new Vector3(movement.x , movement.y , movement.z);
        transform.position = movement;

        rotateFactor = other.rotate();
        transform.eulerAngles = new Vector3(0, 0, rotateFactor);


        growFactor = other.Scale();
    


        if (growFactor < 3)
        {
            growFactor = 3;
            transform.localScale = new Vector3(1, 1, 1) * (growFactor / 10);
        }
        else if (growFactor > 45)
        {
            growFactor = 45;
            transform.localScale = new Vector3(1, 1, 1) * (growFactor / 10);
        }
        else
        {
            transform.localScale = new Vector3(1, 1, 1) * (growFactor / 20);
        }

        if (growFactor / 20 < grow_up && growFactor / 20 > grow_limit)
        {
  
            foreach (SpriteRenderer general in GetComponentsInChildren<SpriteRenderer>())
            {
                general.material.color = Color.yellow;
            }
            

        }
        else
        {
            foreach (SpriteRenderer general in GetComponentsInChildren<SpriteRenderer>())
            {
                general.material.color = Color.black;
            }
   
        }
        triger = other.visiable();
        if (triger == 1)
        {
            foreach (SpriteRenderer general in GetComponentsInChildren<SpriteRenderer>())
            {
                general.material.color = Color.green;
            }
   

        }
        trgIn = other.trg_in();
        if (trgIn == 1)
        {
            foreach (SpriteRenderer general in GetComponentsInChildren<SpriteRenderer>())
            {
                general.material.color = Color.green;
            }
       
        }

        trg_target2 = other.trg_target2();
        trg_target3 = other.trg_target3();
        trg_target4 = other.trg_target4();
        trg_target5 = other.trg_target5();
        if (trg_target2 == 1 || trg_target3 == 1 || trg_target4 == 1 || trg_target5 == 1)
        {

            m_spriteRenderer.color = Color.green;

        }
        if (trg_target3 == 1 || l == 1)
        {
            l = 1;
            grow_limit = 0.65f;
            grow_up = 0.75f;
        }
        if (trg_target4 == 1 || l2 == 1)
        {
            l2 = 1;
            grow_limit = 1.45f;
            grow_up = 1.55f;
        }
       

    }
    
}