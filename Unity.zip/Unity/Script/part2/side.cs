﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class side : MonoBehaviour {

	// Use this for initialization
    public myUDP other;
    SpriteRenderer m_spriteRenderer;
    Color m_newColor;

    private Vector3 movement;
    private float rotate;
    private float counter;
    
   
    
  


	void Start () {
        other = GameObject.FindObjectOfType<myUDP>();
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        m_spriteRenderer.color = Color.black;
        counter = 0;
        movement = other.getHandPosition();
    
		
	}
	
	// Update is called once per frame
    void Update()
    {
        //  0.484--0.521       -2.005f
   

        rotate = other.smallMotor();
  

        transform.localEulerAngles = new Vector3(0, 0, rotate*100/2);
        if (rotate < 0)
        {
            rotate = -1 * rotate;
        }
        transform.localScale = new Vector3(1, 1 + ((rotate * 4.0f) / 10), 1);
    }
}
