﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deneme : MonoBehaviour {

	// Use this for initialization
    private float sliderDeltaX;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
     //   transform.eulerAngles = new Vector3(sliderX, transform.eulerAngles.y, transform.eulerAngles.z);

        sliderDeltaX = 3;
      //  Quaternion localRotation = Quaternion.Euler(0, 0f, sliderDeltaX);
       // transform.rotation = transform.rotation * localRotation;

        Vector3 zero = new Vector3(-5,-2, 0);
        Vector3 x = new Vector3(0, 0, 1);
      //  transform.RotateAround(zero, x, 3 );
    
	}
}
