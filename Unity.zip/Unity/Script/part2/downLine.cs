﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class downLine : MonoBehaviour {
    // Use this for initialization
    public myUDP other;
    SpriteRenderer m_spriteRenderer;
    Color m_newColor;

    private Vector3 movement;
    private float scale;
   

    void Start()
    {
        other = GameObject.FindObjectOfType<myUDP>();
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
       // m_spriteRenderer.color = Color.black;
       

    }

    // Update is called once per frame
    void Update()
    {
        scale = other.smallMotor();
        transform.localScale = new Vector3(1 - ((scale * 6.5f) / 10), 1, 1);
    }
}
