﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class endsign : MonoBehaviour
{


    public myUDP other;
    public float trgEnd;
    public float triger;
    private float l1;
    private float trg_target5 = 0;
    // Use this for initialization
    void Start()
    {
        GameObject.Find("endsign").transform.localScale = new Vector3(0, 0, 0);
        l1 = 0;
    }

    // Update is called once per frame
    void Update()
    {
        other = GameObject.FindObjectOfType<myUDP>();
        triger = other.visiable();
        trgEnd = other.trg_in();
        if (triger == 1 || l1 ==1 )
        {
            l1 = 1;
        }
        trg_target5 = other.trg_target5();

        if (trg_target5 == 1 && l1 == 1)
        {
            GameObject.Find("endsign").transform.localScale = new Vector3(2, 2, 1);  
        }
    }

    /* void dissapp(){
         GameObject.Find("start").transform.localScale = new Vector3(1,1,1);
        
     } */

}