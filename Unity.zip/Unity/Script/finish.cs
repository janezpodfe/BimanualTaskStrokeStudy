﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class finish : MonoBehaviour
{

    //	public GameObject Fly;
    //	public float spawnTime = 3f;

    public float rotateSpeedX;
    public float rotateSpeedY;
    //	public float centerPointPositionOffsetX;
    public float rotateSpeedZ = 25.0f;

    public int counter = -150;
    private int counter_2 = 0;
    private int x = 75;
    private int y = 75;
    private int z = 225;
    public float triger = 0;

    public Vector2 targetPos;


    public Vector3 StartPosition_Plane = new Vector3(5.0f, 3.0f, 0);
    public myUDP other;
    public Vector3 desired_point = new Vector3(5.0f, 3.0f, 0);


    // Use this for initialization
    void Start()
    {
        GameObject.Find("finish").transform.localScale = new Vector3(0, 0, 0);
        // counter = 0;
        other = GameObject.FindObjectOfType<myUDP>();

        // Spawn();
        //	transform.position = StartPosition_Plane;



    }

    // Update is called once per frame
    void Update()
    {
        triger = other.visiable();
        if (triger == 1)
        {
            Invoke("app", 3.0f);
        }
        //desired_point = other.getHandPosition();
        //Debug.Log("desired x" + desired_point.x);

        //dondurmeyi alt satirdan durdurdum
        //RotationPlane();

        //other.setTargetPosition(desired_point.x, desired_point.y, desired_point.z);
        float xx = 3.1f;
        // other.setTargetPosition(xx,xx,xx);
        //  targetPos = other_1.getTargetPos();
        targetPos = other.getTargetPos();
        Spawn();

    }

    public void Spawn()
    {
        
        Vector3 targetPos_1 = new Vector3(targetPos.x, targetPos.y+2, 0);
        transform.position = targetPos_1;

        //ust taraftakiler matlabden veri alirken

        //float spawnPointX = Random.Range(-7.5f,7.5f);
        //int spawnPointY = Random.Range(-4,4);

        //Vector3 spawnPosition = new Vector3(spawnPointX,spawnPointY,0);
        //transform.position =spawnPosition;  
        // ust 4 satir kod unityden veri alirken

        //desired_point = spawnPosition;



        //		transform.position =desired_point;

        //		centerPointPositionOffsetX = spawnPointX;
        //other.setTargetPosition(spawnPosition.x, spawnPosition.y, spawnPosition.z);



    }
    void app()
    {
        GameObject.Find("finish").transform.localScale = new Vector3(1, 1, 1);
    }



    void RotationPlane()
    {
        transform.eulerAngles = new Vector3(0, 0, counter);
        if (counter_2 < x)
        {
            counter++;
            counter_2++;
        }
        if (counter_2 >= y)
        {
            counter--;
            counter_2++;
        }
        if (counter_2 == z)
        {
            counter_2 = 0;
            x = 150;
            y = 150;
            z = 300;
        }
    }
    /*void RotationPlane() {
        counter++;
		
        if (counter < 180 ) {
			
			
            transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY* Time.deltaTime, rotateSpeedZ* Time.deltaTime ,Space.World);
		
        }
        else {
			
            transform.Rotate(-rotateSpeedX * Time.deltaTime, -rotateSpeedY* Time.deltaTime, -rotateSpeedZ* Time.deltaTime,Space.World);
			
        }
		
        if (counter > 360) {
			
            counter = 0;
        }
    } */

}
