﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour {



    public myUDP other;
    private Vector2 targetPos;
    private float angle;
    private float scale;
	// Use this for initialization
	void Start () {
        other = GameObject.FindObjectOfType<myUDP>();
	}
	
	// Update is called once per frame
	void Update () {
        targetPos = other.getTargetPos();
        targetPos.x = ((targetPos.x * 5.27f) / 24.5f)*100;
        targetPos.y=((targetPos.y * 4.88f) / 23)*100;
        transform.position = targetPos;

        angle = other.angleofTarget();
        transform.localEulerAngles = new Vector3(0, 0, angle);

        scale = other.scaleofTarget();
        scale = scale*3 + 1;
        transform.localScale = new Vector3(1, 1, 1) * (scale);
	}
}
