﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class AimC : MonoBehaviour
{

    public float speed = 1.0f;
    public float rotateSpeedX = 0;
    public float rotateSpeedY = 0;
    public float rotateSpeedZ = 25;


    public Vector3 possition;
    public float trgIn;

    public int counter_1;
    public int comp_counter;
    public Vector3 plane_position;
    public Quaternion plane_rotation;
    public Quaternion rocket_rotation;

    public Animator anim;

    public float angle_rad;
    public float angle;
    public float controlSignal1;


    public float roc_angle_rad;
    public float roc_angle;

    //	public Server other;
    //	 udpServer;
    private float try1;
    private float try2;
    public float try3 = 0;
    public float try4 = 4.1f;

    private float trg_target2 = 0;
    private float trg_target3 = 0;
    private float trg_target4 = 0;
    private float trg_target5 = 0;

    private float l = 0;
    private float l2 = 0;
    private float grow_limit = 0.95f;
    private float grow_up = 1.05f;

    private float color;
    


    public myUDP other;

    //public PlaneMove plane;

    public Vector3 movement;

    public float growFactor;
    public float rotateFactor;
    private float triger;
    private float colorCounter=0;
    

    /*private IEnumerator Scaling()
    {
        while (true)
        {
            while (upScale)
            {
                if (growFactor > maxtargetScale)
                {
                    upScale = false;
                }
                transform.localScale += new Vector3(1, 1, 1) * growFactor / 100;

            }
            while (!upScale)
            {
                if (growFactor < mintargetScale)
                {
                    upScale = true;
                }
                transform.localScale -= new Vector3(1, 1, 1) * growFactor / 100;
            }
        }
    } */

    SpriteRenderer m_spriteRenderer;
       Color m_newColor;



    // Use this for initialization
    void Start()
    {

        //	counterAngle = 0;
        anim = GetComponent<Animator>();

        other = GameObject.FindObjectOfType<myUDP>();

       // plane = GameObject.FindObjectOfType<PlaneMove>();

        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        m_spriteRenderer.color = Color.black;
        //StartCoroutine(Scaling());



    }

    // Update is called once per frame
    void Update()
    {
        //float try3 = 0;
       // other.setTargetPosition(try3, try3, try3);
        //		_ServerToMove.setScaling(float scaleFactorX = 1.0f,scaleFactorY);

        var move = new Vector3(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"), 0);
        transform.position += move * speed * Time.deltaTime;


        if (Input.GetKey(KeyCode.O))
        {

            transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY * Time.deltaTime, rotateSpeedZ * Time.deltaTime);

            if (comp_counter < 360)
            {
                comp_counter++;
                //				Debug.Log("counter rocket" + comp_counter);
            }

        }
        if (Input.GetKey(KeyCode.L))
        {

            transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY * Time.deltaTime, -rotateSpeedZ * Time.deltaTime);
            comp_counter--;
            //			Debug.Log("counter rocket" + comp_counter);
        }

        possition = transform.position;
        //	Debug.Log("current pos is" + possition);
      //  counter_1 = GameObject.Find("Rec").GetComponent<PlaneMove>().counter;
        //	Debug.Log("counter is" + counter_1);

        // getting a initial position of plane

        //	plane_position = GameObject.Find("Fly (2)").GetComponent<PlaneMove>().SpawnPosition;

        //plane_position = GameObject.Find("Rec").transform.position;

        //plane_rotation = GameObject.Find("Rec").transform.rotation;
        //		Debug.Log("plane pos" + plane_rotation);

        angle_rad = (Mathf.Asin(plane_rotation.z / plane_rotation.w));
        angle = angle_rad * Mathf.Rad2Deg;
        //		Debug.Log("angle" + angle);

        rocket_rotation = GameObject.Find("AimC").transform.rotation;

        roc_angle_rad = (Mathf.Asin(rocket_rotation.z / rocket_rotation.w));
        roc_angle = roc_angle_rad * Mathf.Rad2Deg;
    
        //        controlSignal1 = angle;



       /* cc if (possition.x > plane_position.x - 0.5 && possition.y > plane_position.y - 0.5 && possition.x < plane_position.x + 0.5 &&
                        possition.y < plane_position.y + 0.5 && roc_angle < angle + 1 && roc_angle > angle - 1 && growFactor / 20 < 1.1 && growFactor / 20 > 0.9)
                {
                    try3 = 1.1f;
                    other.setTargetPosition(try3, try3, try3);
                    //plane.Spawn();
                                Debug.Log("rocket angle" + roc_angle);
                } */
         

        /*	if ( possition.x >plane_position.x-0.5 && possition.y >plane_position.y-0.5 && possition.x<plane_position.x+0.5 && 
                possition.y<plane_position.y+0.5  && roc_angle < angle+5 && roc_angle > angle-5 )
            {
        //		transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY* Time.deltaTime, rotateSpeedZ * Time.deltaTime);
                anim.Play("BlowUp");
            }
            else 
            {
               // anim.Play("OrdRocket");
            } */
        //	udpServer.setScaling( scaleFactorX, scaleFactorY);


        movement = other.getHandPosition();
        //movement.x = movement.x * 100/3;
  

       // movement.y = movement.y * 100/5;
       // movement.z = movement.z * 195/1000;


        transform.position = movement*20 ;
       // other.setAimPosition(movement.x * -100 /2, movement.y * -100/2, 0);
        
     
        

        growFactor = other.Scale();

        transform.localScale = new Vector3(1, 1, 1) * (growFactor*3+1);
       /* growFactor = (growFactor*100) + 23;
        

        if(growFactor < 3)
        {
            growFactor = 3;
            transform.localScale = new Vector3(1, 1, 1) * (growFactor / 10);
        }
        else if (growFactor > 45)
        {
            growFactor = 45;
            transform.localScale = new Vector3(1, 1, 1) * (growFactor / 10);
        }
        else
        {
            transform.localScale = new Vector3(1, 1, 1) * (growFactor / 20);
        } */

        rotateFactor = other.angle();
        //transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY * Time.deltaTime, rotateFactor * Time.deltaTime*100);
       /* if (roc_angle < rotateFactor * -63)
        {
            transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY * Time.deltaTime, rotateFactor * Time.deltaTime * 100);
            roc_angle++;
        }  */
        /*else if (roc_angle > rotateFactor *63)
        {
            transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY * Time.deltaTime, rotateFactor * Time.deltaTime * -100);
            roc_angle--;
        } */

       // rotateFactor = rotateFactor * 66 ;
        transform.localEulerAngles = new Vector3(0, 0, rotateFactor);


        color = other.color();

        if (color == 1 )
        {
            m_spriteRenderer.color = Color.green;
            colorCounter++;
        }
        else if (color == 2)
        {
            m_spriteRenderer.color = Color.yellow;
        }
        else
        {
            colorCounter = 0;
            m_spriteRenderer.color = Color.black;
        }
       /* if (growFactor / 20 < grow_up && growFactor / 20 > grow_limit)
        {
            //		transform.Rotate(rotateSpeedX * Time.deltaTime, rotateSpeedY* Time.deltaTime, rotateSpeedZ * Time.deltaTime);
            //      anim.Play("BlowUp");
            m_spriteRenderer.color = Color.yellow;
        }
        else
        {
            m_spriteRenderer.color = Color.black;
        }
        triger = other.startTrg();
        if (triger == 1)
        {

            m_spriteRenderer.color = Color.green;
            
        }
        trgIn = other.recApp();
        if (trgIn == 1)
        {
            m_spriteRenderer.color = Color.green;
        }
       // plane.Spawn();

        trg_target2 = other.target2App();
        trg_target3 = other.target3App();
        trg_target4 = other.target4App();
        trg_target5 = other.target5App();
        if (trg_target2 == 1 || trg_target3 == 1 || trg_target4 == 1 || trg_target5 == 1)
        {

            m_spriteRenderer.color = Color.green;

        }
        if (trg_target3 == 1 || l == 1)
        {
            l = 1;
            grow_limit = 0.65f;
            grow_up = 0.75f;
        }
        if (trg_target4 == 1 || l2 == 1)
        {
            l2 = 1;
            grow_limit = 1.45f;
            grow_up = 1.55f;
        }*/
       
    }
}


