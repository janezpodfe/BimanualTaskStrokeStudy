﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSelect : MonoBehaviour {

    public myUDP other;
    private float expType;
    private float oldExp;
    private float K;
    private float l;
	// Use this for initialization
	void Start () {
        other = GameObject.FindObjectOfType<myUDP>();
        oldExp = 3;
        K = 0;
        l = 0;
      
	}
	
	// Update is called once per frame
	void Update () {

        expType = other.expType();
        

        //if(Input.GetKeyDown(KeyCode.Space))
        //{
        //if (expType != oldExp)
        //{
       
        if (expType == 1 && K==0)
        {
           
            SceneManager.LoadScene("HapticMaster", LoadSceneMode.Additive);
            if (l == 1)
            {
                SceneManager.UnloadSceneAsync("HapticMaster2");
            }
            K = 1;
       
        }
        else if ( expType ==2 && K==1 )
        {
            SceneManager.UnloadSceneAsync("HapticMaster");
   
            SceneManager.LoadScene("HapticMaster3", LoadSceneMode.Additive);
            K = 2;
        }
        else if (expType ==3 && K ==2)
        {

            SceneManager.UnloadSceneAsync("HapticMaster3");
            SceneManager.LoadScene("HapticMaster2", LoadSceneMode.Additive);
            K = 0;
            l = 1;
        }
        }

      //  oldExp = expType;
	//}
    
}
