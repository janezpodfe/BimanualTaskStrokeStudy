﻿// -------------------------------------------------------------------------- //
// 					Bimeo Game UDP Server						 	  		  //
// -------------------------------------------------------------------------- //
//	File:			GameUDPServer.js							  		  	  //
//	Description:	Game UDP Server script for BiMeo Games		  	  		  //
// -------------------------------------------------------------------------- //
// 	Date created:	May 2013												  //	
//	Date modified:	July 2013												  //
// -------------------------------------------------------------------------- //
// 	Created by:		Matjaz Mihelj											  //	
//	Extended by:	Ales Hribar								 				  //
// -------------------------------------------------------------------------- //
//					All rights reserved Kinestica							  //
// -------------------------------------------------------------------------- //

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.IO;


public class myUDP : MonoBehaviour
{

    // RECEIVE THREAD PARAMETERS
    const int PORT_RECEIVE = 25008;
    const int NUM_RECEIVE_FLOATS = 43;
    private Thread UDPThreadReceive;
    float[] dataReceive = new float[NUM_RECEIVE_FLOATS];
    bool isRunningReceive = true;

    // SEND THREAD PARAMETERS
    const int PORT_SEND = 25106;
    const int NUM_SEND_FLOATS = 30;
    private Thread UDPThreadSend;
    float[] dataSend = new float[NUM_SEND_FLOATS];
    bool isRunningSend = true;

    //	public bool showInput = true;
    //	private string IPSendAddress;	

    // DEBUG MODE PARAMETERS
    bool showDebug = false;
    private string udpStatus = "";

    //////////////////////////////////////////////////////
    // 	UPD SEND AND RECEIVE INITIALIZATION
    //////////////////////////////////////////////////////	
    void Start()
    {
        try
        {
            //Starting the UDP Server thread.
            UDPThreadReceive = new Thread(new ThreadStart(StartReceive));
            UDPThreadSend = new Thread(new ThreadStart(StartSend));

            isRunningReceive = true;
            isRunningSend = true;

            UDPThreadReceive.IsBackground = true;
            UDPThreadSend.IsBackground = true;

            UDPThreadReceive.Start();
            UDPThreadSend.Start();

            udpStatus = "Started UDP Receiver and Send Threads!";
        }
        catch (Exception e)
        {
            udpStatus = "An UDP Exception has occurred: " + e.ToString();
        }
    }

    //////////////////////////////////////////////////////
    // 	STOP RECEIVING AND SENDING DATA WHEN APPLICATION QUIT
    //////////////////////////////////////////////////////	
    void OnApplicationQuit()
    {
        isRunningReceive = false;
        isRunningSend = false;
        udpStatus = "UDP Stopped.";
    }


    //////////////////////////////////////////////////////
    // 	RECEIVING DATA THROUGH UDP PORT
    //////////////////////////////////////////////////////		
    void StartReceive()
    {
        byte[] data = new byte[NUM_RECEIVE_FLOATS * 4];

        IPEndPoint ipep = new IPEndPoint(IPAddress.Any, PORT_RECEIVE);
        Socket newsock = new Socket(AddressFamily.InterNetwork,
                      SocketType.Dgram, ProtocolType.Udp);

        try
        {
            newsock.ReceiveTimeout = 1000;
            newsock.Bind(ipep);
            udpStatus = "Waiting for a client...";
            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
            EndPoint Remote = (EndPoint)(sender);

            try
            {
                newsock.ReceiveFrom(data, ref Remote);
                udpStatus = "Message received";

                while (isRunningReceive)
                {
                    data = new byte[1024];

                    try
                    {
                        newsock.ReceiveFrom(data, ref Remote);

                        // GET VALUES
                        for (int i = 0; i < NUM_RECEIVE_FLOATS; i++)
                        {
                            dataReceive[i] = BitConverter.ToSingle(data, sizeof(float) * i);
                        }

                    }
                    catch (Exception e)
                    {
                        udpStatus = "An UDP Exception has occurred. Problem Receiving:  " + e.ToString();
                    }
                }

                newsock.Close();
            }
            catch (Exception e)
            {
                udpStatus = "An UDP Exception has occurred. Problem Receiving First:  " + e.ToString();
            }
        }
        catch (Exception e)
        {
            udpStatus = "An UDP Exception has occurred. Problem Connecting: " + e.ToString();
        }
    }

    //////////////////////////////////////////////////////
    // 	SENDING DATA THROUGH UDP PORT
    //////////////////////////////////////////////////////	

    void StartSend()
    {

        UdpClient sock = new UdpClient();
        IPEndPoint iep = new IPEndPoint(IPAddress.Parse("192.168.65.245"), PORT_SEND);

        byte[] dataB;
        dataB = new byte[NUM_SEND_FLOATS * sizeof(float)];

        while (isRunningSend)
        {
            Thread.Sleep(20);

            for (int i = 0; i < NUM_SEND_FLOATS; i++)
            {
                byte[] temp = BitConverter.GetBytes(dataSend[i]);

                for (int j = 0; j < sizeof(float); j++)
                {
                    dataB[i * sizeof(float) + j] = temp[j];
                }

            }

            try
            {
                sock.Send(dataB, dataB.Length, iep);

            }
            catch (Exception e)
            {
                udpStatus = "An UDP Exception has occurred. Problem Connecting: " + e.ToString();
            }
        }

        sock.Close();

    }

    //////////////////////////////////////////////////////
    // 	SET STATUS FOR RECEIVING AND SENDING DATA
    //////////////////////////////////////////////////////

    void SetIsRunningReceive(bool isRunReceive)
    {
        isRunningReceive = isRunReceive;
    }

    void SetIsRunningSend(bool isRunSend)
    {
        isRunningSend = isRunSend;
    }


    //////////////////////////////////////////////////////
    // 	CLOSE UDP CONNECTION
    //////////////////////////////////////////////////////	
    public void closeConnection()
    {
        isRunningReceive = false;
        isRunningSend = false;
    }


    //////////////////////////////////////////////////////
    // 	PARSE DATA FROM RECEIVE UDP PORT
    //////////////////////////////////////////////////////

    // SIMULINK COUNTER COUNTS WIHT 100 Hz FREQUENCY
    /*public float getMatlabCounter()
    {
        return dataReceive[0];
    } */

    public float expType()
    {
        return dataReceive[0];
    }

    // HAND POSITION IN UNITY CS
    public Vector2 getHandPosition()
    {
        Vector2 tmpVec = new Vector2(dataReceive[1], dataReceive[2]);
        return tmpVec;
    }

    public  float Scale()
    {
        return  dataReceive[3];
        
    }

    public float angle()
    {
        return dataReceive[4];

    }
    public float angleSmall()
    {
        return dataReceive[5];
    }

    /* // HAND ORIENTATION IN UNITY CS
    public Quaternion getHandOrientation()
    {
        Quaternion tmpVec = new Quaternion(dataReceive[5], dataReceive[6], dataReceive[7], dataReceive[4]);
        return tmpVec;
    }
      */
    public Vector2 getTargetPos()
    {
        Vector2 posTarget = new Vector2(dataReceive[6], dataReceive[7]);
        return posTarget;
    }
    public float angleofTarget()
    {
        return dataReceive[8];

    }
    public float scaleofTarget()
    {
        return dataReceive[9];

    }
    // GLOBAL FORCE IN UNITY CS
    public Vector3 getStartPos()
    {
        Vector3 position = new Vector3(dataReceive[80], dataReceive[90]);
        return position;
    }

    public float exp2()
    {
        return dataReceive[10];

    }
    public float color()
    {
        return dataReceive[11];

    }
    public Vector2 getUnitVector()
    {
        Vector2 unitVector = new Vector2(dataReceive[11], dataReceive[12]);
        return unitVector;
    }
    public float vel()
    {
        return dataReceive[13];

    }
    public  Vector2 startBall()
    {
        Vector2 ballStartPos = new Vector2(dataReceive[14], dataReceive[15]);
        return ballStartPos;
    }
    public float trg_target2()
    {
        return dataReceive[16];

    }
    public float trg_target3()
    {
        return dataReceive[17];

    }
    public float trg_target4()
    {
        return dataReceive[18];

    }
    public float trg_target5()
    {
        return dataReceive[19];

    }
    public float smallMotor()
    {
        return dataReceive[20];

    }

    public float startTrg()
    {
        return dataReceive[21];
    }
    public float recApp()
    {
        return dataReceive[25];
    }
    public float target2App()
    {
        return dataReceive[22];
    }
    public float target3App()
    {
        return dataReceive[23];
    }
    public float target4App()
    {
        return dataReceive[24];
    }
    public float target5App()
    {
        return dataReceive[26];
    }
 

   

    // SCALED LOCAL FORCE IN UNITY CS
    public Vector3 getLocalScaledForce()
    {
        Vector3 tmpVec = new Vector3(dataReceive[118], dataReceive[1148], dataReceive[191]);
        return tmpVec;
    }

    // ARM POWER GIVEN AS RGB COMPONENTS, RED WHEN PARETIC ARM SUPPORTED AND GREEN VICE VERSA
    public Vector3 getArmPowerRatio()
    {
        Vector3 tmpVec = new Vector3(dataReceive[20], dataReceive[21], dataReceive[22]);
        return tmpVec;
    }

    // SHOULDER JOINT ANGLES
    public Vector3 getShoulderAngles()
    {
        Vector3 tmpVec = new Vector3(dataReceive[23], dataReceive[24], dataReceive[25]);
        return tmpVec;
    }

    // ELBOW JOINT ANGLE
    public float getElbowAngle()
    {
        return dataReceive[26];
    }

    // WRIST JOINT ANGLES
    public Vector3 getWristAngles()
    {
        Vector3 tmpVec = new Vector3(dataReceive[27], dataReceive[28], dataReceive[29]);
        return tmpVec;
    }

    // SHOULDER JOINT TORQUES
    public Vector3 getShoulderTorques()
    {
        Vector3 tmpVec = new Vector3(dataReceive[30], dataReceive[31], dataReceive[32]);
        return tmpVec;
    }

    // ELBOW JOINT TORQUE
    public float getElbowTorque()
    {
        return dataReceive[33];
    }

    // WRIST JOINT TORQUES
    public Vector3 getWristTorques()
    {
        Vector3 tmpVec = new Vector3(dataReceive[34], dataReceive[35], dataReceive[36]);
        return tmpVec;
    }

    // DEVICE CONNECTED (RIGHT = 1 OR LEFT = 2)
    public int getDeviceConnected()
    {
        return (int)dataReceive[37];

    }

    // BATTERY STATUS (BIMEO, FOREARM, UPPER ARM, TRUNK)
    public Vector4 getBatteryStatus()
    {
        Vector4 tmpVec = new Vector4(dataReceive[38], dataReceive[39], dataReceive[40], dataReceive[41]);
        return tmpVec;
    }

    // DETECT SENSOR ERROR (FORCE OR IMU)
    public int getSensorError()
    {
        return (int)dataReceive[42];

    }
    //////////////////////////////////////////////////////
    // 	COLLECT DATA FOR SEND UDP PORT
    //////////////////////////////////////////////////////	

    // BIMEO INITIALIZATION
    public void startBimeoInitialization(float startInitialization)
    {
        dataSend[0] = startInitialization;
    }

    // SESSION TERMINATION
    public void terminateBimeoSession(float terminateSession)
    {
        dataSend[1] = terminateSession;
    }

    // TARGET POSITION
    public void setTargetPosition(float targetPositionX, float targetPositionY, float targetPositionZ)
    {
        dataSend[2] = targetPositionX;
        dataSend[3] = targetPositionY;
        dataSend[4] = targetPositionZ;
    }

    public void endLock(float lock_end)
    {
        dataSend[5] = lock_end;
    }




    // POSITION OFFSET
    public void setAimPosition(float centerPointPositionOffsetX, float centerPointPositionOffsetY, float centerPointPositionOffsetZ)
    {

        dataSend[6] = centerPointPositionOffsetX;
        dataSend[6] = centerPointPositionOffsetY;
        dataSend[7] = centerPointPositionOffsetZ;
    }
    public void setIntialTriger(float targetPositionX, float targetPositionY)
    {
        dataSend[8] = targetPositionX;
        dataSend[9] = targetPositionY;
      
    }

    


    void OnGUI()
    {
        if (showDebug)
        {
            Rect rectObj = new Rect(20, Screen.height - 60, Screen.width - 40, 22);

            GUIStyle style = new GUIStyle();
            style.alignment = TextAnchor.UpperLeft;

            GUI.Box(rectObj, "UDP Status: " + udpStatus, style);
        }

        // TOGGLE DISPLAY
        if (Input.GetKey(KeyCode.F12))
        {
            showDebug = true;
        }

        if (Input.GetKey(KeyCode.C))
        {
            showDebug = false;
        }
    }
}


