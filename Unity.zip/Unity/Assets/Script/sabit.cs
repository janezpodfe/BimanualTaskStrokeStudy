﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sabit : MonoBehaviour
{

    SpriteRenderer m_spriteRenderer;
    Color m_newColor;
    public myUDP other;
    private float color;
    private float colorCounter = 0;
    // Use this for initialization
    void Start()
    {
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        m_spriteRenderer.color = Color.black;
        other = GameObject.FindObjectOfType<myUDP>();
    }

    // Update is called once per frame
    void Update()
    {
        color = other.color();
        if (color == 1)
        {
            m_spriteRenderer.color = Color.green;
            colorCounter++;
        }
        else if (color == 2)
        {
            m_spriteRenderer.color = Color.yellow;
        }
        else
        {
            colorCounter = 0;
            m_spriteRenderer.color = Color.black;
        }
    }
}
