﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetSideLeft : MonoBehaviour
{

    SpriteRenderer m_spriteRenderer;
    Color m_newColor;
    public myUDP other;
    private float rotation;
    // Use this for initialization
    void Start()
    {
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        //m_spriteRenderer.color = Color.black;
        other = GameObject.FindObjectOfType<myUDP>();
    }

    // Update is called once per frame
    void Update()
    {
        rotation = other.exp2();
        transform.localScale = new Vector3(0.75f, (0.8f + (rotation / 44)), 1);
    }
}
