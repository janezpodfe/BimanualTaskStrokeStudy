﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimSideLeft : MonoBehaviour
{

    SpriteRenderer m_spriteRenderer;
    Color m_newColor;
    public myUDP other;
    private float rotation;
    private float color;
    private float colorCounter = 0;
    private float limit;
    // Use this for initialization
    void Start()
    {
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        m_spriteRenderer.color = Color.black;
        other = GameObject.FindObjectOfType<myUDP>();
    }

    // Update is called once per frame
    void Update()
    {
        rotation = other.angleSmall();
       /* limit = (0.8f + (rotation / 44));
        if (limit < 0.24f)
        {
            limit = 0.24f;
        } */
        transform.localScale = new Vector3(0.75f, (0.8f + (rotation / 44)), 1);

       

        color = other.color();

        if (color == 1)
        {
            m_spriteRenderer.color = Color.green;
            colorCounter++;
        }
        else if (color == 2)
        {
            m_spriteRenderer.color = Color.yellow;
        }
        else
        {
            colorCounter = 0;
            m_spriteRenderer.color = Color.black;
        }
    }
}
