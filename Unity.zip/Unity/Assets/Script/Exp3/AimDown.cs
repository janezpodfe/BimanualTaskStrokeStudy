﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimDown : MonoBehaviour
{


    public myUDP other;
    SpriteRenderer m_spriteRenderer;
    Color m_newColor;
    private float color;
    private float colorCounter = 0;

    private float rotation;
    private float limit;
    private float limit2;
    private float limit2minus;
    // Use this for initialization
    void Start()
    {
        other = GameObject.FindObjectOfType<myUDP>();
        m_spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        m_spriteRenderer.color = Color.black;

    }

    // Update is called once per frame
    void Update()
    {
        rotation = other.angleSmall();
       /* limit = rotation;
        if (limit < -26)
        {
            limit = -26f;
    } */
        transform.localEulerAngles = new Vector3(0, 0, rotation);

        /*limit2 = (0.8f + (-rotation / 150));
        if (limit2 > 0.96)
        {
            limit2 = 0.96f;
        }
        limit2minus = (0.8f + (rotation / 150));
        if (limit2minus > 0.96)
        {
            limit2minus = 0.96f;
        } */

        transform.localScale = new Vector3((0.8f + (-rotation / 150)), 0.75f, 1);
        if (rotation >= 0)
        {
            transform.localScale = new Vector3((0.8f + (rotation / 150)), 0.75f, 1);
        }
        color = other.color();
        if (color == 1)
        {
            m_spriteRenderer.color = Color.green;
            colorCounter++;
        }
        else if (color == 2)
        {
            m_spriteRenderer.color = Color.yellow;
        }
        else
        {
            colorCounter = 0;
            m_spriteRenderer.color = Color.black;
        }

    }
}