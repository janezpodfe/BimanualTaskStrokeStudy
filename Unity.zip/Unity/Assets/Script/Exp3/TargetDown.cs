﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetDown : MonoBehaviour
{


    public myUDP other;

    private float rotation;
    // Use this for initialization
    void Start()
    {
        other = GameObject.FindObjectOfType<myUDP>();

    }

    // Update is called once per frame
    void Update()
    {
        rotation = other.exp2();
        transform.localEulerAngles = new Vector3(0, 0, rotation);
        transform.localScale = new Vector3((0.8f + (-rotation / 120)), 0.8f, 1);
        if (rotation >= 0)
        {
            transform.localScale = new Vector3((0.8f + (rotation / 120)), 0.8f, 1);
        }
    }
}
