﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class downright : MonoBehaviour {

    
    public myUDP other;

    private float rotation;
    private float limit;
    private float limit2;
    private float angleLimit;
	// Use this for initialization
	void Start () {
        other = GameObject.FindObjectOfType<myUDP>();
        
	}
	
	// Update is called once per frame
	void Update () {
        rotation = other.angleSmall();

        /*angleLimit = rotation;

        if (angleLimit <  -34)
        {
            angleLimit = -34;
        }

        limit = (1 + (-rotation / 110));
        if (limit > 1.3)
        {
            limit = 1.3f;
        }

        limit2 = (1 + (rotation / 110));

        if (limit2 > 1.3)
        {
            limit2 = 1.3f;
        }
         */

        transform.localEulerAngles = new Vector3(0, 0, rotation);
        transform.localScale = new Vector3((1 + (-rotation / 110)), 1, 1);
        if (rotation >= 0)
        {
            transform.localScale = new Vector3((1 + (rotation / 110)), 1, 1);
        }
	}
}
